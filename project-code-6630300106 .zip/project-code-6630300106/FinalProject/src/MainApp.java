package FinalProject.src;

import javax.swing.SwingUtilities;

public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            // Event Dispatch Thread (EDT)
            @Override
            public void run(){
                AppWindow app = new AppWindow();
                app.setLocationRelativeTo(null);
                app.setVisible(true);
            }
        });
    }
}