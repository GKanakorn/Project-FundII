package FinalProject.src;

import java.util.Set;
import javax.swing.*;

public class AppWindow extends JFrame{
    private ProfilePage profilePage;
    private BookingPage bookingPage;
    private PaymentPage paymentPage;
    private Receipt receipt;

    public AppWindow() {
        setTitle("TrainBooking.com");
        profilePage = new ProfilePage(this);
        setContentPane(profilePage);
        setSize(700,700);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void bookingButtonPressed(Data data){
        bookingPage = new BookingPage(this, data);
        setContentPane(bookingPage);
        revalidate();
    }

    public void paymentButtonPressed(Data data , Set<String> selectedSeats) {
        paymentPage = new PaymentPage(this, data ,selectedSeats);
        setContentPane(paymentPage);
        revalidate();
    }
    
    public void showReceiptPage(Data data, Set<String> selectedSeats ,int totalPrice) {
        receipt = new Receipt(this, data, selectedSeats , totalPrice);
        setContentPane(receipt);
        setTitle("RecieptTrainBooking.com");
        setSize(300,430);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        revalidate();
    }

    public void showProfilePage() {
        setContentPane(profilePage);
        revalidate();
    }

    public void showBookingPage() {
        setContentPane(bookingPage);
        revalidate();
    }
}
