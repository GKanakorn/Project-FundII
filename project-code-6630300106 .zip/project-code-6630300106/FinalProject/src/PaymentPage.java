package FinalProject.src;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Set;

public class PaymentPage extends JPanel {
    private AppWindow app;
    private JLabel nameLabel;
    private JLabel phoneNumberLabel;
    private JLabel emailLabel;
    private JLabel departureStationLabel;
    private JLabel destinationStationLabel;
    private JLabel priceLabel;
    private JLabel seatLabel;
    private JLabel totalpriceLabel1;
    private int totalPrice;
    private Set<String> selectedSeats;

    public PaymentPage(AppWindow app, Data data, Set<String> selectedSeats) {
        this.app = app;
        this.selectedSeats = selectedSeats;
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(10, 10, 10, 10));
        setBackground(new Color(199,21,133));

        //สร้าง Panel แสดงข้อมูล
        JPanel topPanel = new JPanel(new GridLayout(1, 1));
        topPanel.setBackground(new Color(199,21,133));
        topPanel.setBorder(new EmptyBorder(0, 0, 10,0 ));

        // ส่วนแสดงข้อมูลผู้ใช้และรายละเอียดการจอง ชื่อ เบอร์โทร อีเมล
        JPanel dataPanel1 = new JPanel(new GridLayout(4, 1));
        dataPanel1.setBorder(new EmptyBorder(10, 10, 10, 0));
        dataPanel1.setBackground(new Color(255,20,147));
        //ชื่อ
        nameLabel = new JLabel("Name : " + data.getName());
        nameLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 16));
        nameLabel.setForeground(Color.WHITE);
        dataPanel1.add(nameLabel);
        //เบอร์โทร
        phoneNumberLabel = new JLabel("Phone Number : " + data.getPhoneNumber());
        phoneNumberLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 16));
        phoneNumberLabel.setForeground(Color.WHITE);
        dataPanel1.add(phoneNumberLabel);
        //อีเมล
        emailLabel = new JLabel("Email : " + data.getEmail());
        emailLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 16));
        emailLabel.setForeground(Color.WHITE);
        dataPanel1.add(emailLabel);

        topPanel.add(dataPanel1);

        // ส่วนแสดงข้อมูลผู้ใช้และรายละเอียดการจอง สถานีต้นทาง สถานีปลายทาง ราคา เลขที่นั่ง
        JPanel dataPanel2 = new JPanel(new GridLayout(4, 1));
        dataPanel2.setBorder(new EmptyBorder(10, 0, 10, 0));
        dataPanel2.setBackground(new Color(255,20,147));
        //สถานีต้นทาง
        departureStationLabel = new JLabel("Departure Station :" + data.getDepartureStation());
        departureStationLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 16));
        departureStationLabel.setForeground(Color.WHITE);
        dataPanel2.add(departureStationLabel);
        //สถานีปลายทาง
        destinationStationLabel = new JLabel("Destination Station :" + data.getDestinationStation());
        destinationStationLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 16));
        destinationStationLabel.setForeground(Color.WHITE);
        dataPanel2.add(destinationStationLabel);
        //ราคา
        priceLabel = new JLabel("Price : " + data.getPrice() + " Baht/Person");
        priceLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 16));
        priceLabel.setForeground(Color.WHITE);
        dataPanel2.add(priceLabel);
        //ที่นั่ง
        seatLabel = new JLabel("Selected Seats : " + selectedSeats); // แสดงที่นั่งที่เลือก
        seatLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 16));
        seatLabel.setForeground(Color.WHITE);
        dataPanel2.add(seatLabel);

        topPanel.add(dataPanel2);
        
        add(topPanel, BorderLayout.PAGE_START);

        JPanel paymentPanel = new JPanel(new GridLayout(2, 2));
        paymentPanel.setBackground(new Color(255,182,193));

        //เรียกใช้เมทอดคำนวณราคารวม มาเก็บในตัวแปร totalPrice
        totalPrice = calculateTotalPrice(data.getPrice(), selectedSeats.size());

        //แสดงราคารวมใน text "Total Price"
        JLabel totalPriceLabel = new JLabel("Total Price: ");
        totalPriceLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 45));
        totalPriceLabel.setHorizontalAlignment(SwingConstants.CENTER);
        totalPriceLabel.setForeground(Color.RED);
        paymentPanel.add(totalPriceLabel);
        //แสดงเลขราคารวม
        totalpriceLabel1 = new JLabel("" + totalPrice + " Baht");
        totalpriceLabel1.setFont(new Font("Segoe UI Black", Font.PLAIN, 45));
        totalpriceLabel1.setForeground(Color.RED);
        totalpriceLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        paymentPanel.add(totalpriceLabel1);
        //แสดง qr code
        try {
            ImageIcon backgroundImage = new ImageIcon(ImageIO.read(new File("C:/Users/guy91/Desktop/ProgramFund II/project-code-6630300106/FinalProject/src/Image/payment.jpg")));
            JLabel backgroundLabel = new JLabel(backgroundImage);
            paymentPanel.add(backgroundLabel);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //สร้าง Panel แสดงเลขบัญชี
        JPanel payPanel = new JPanel();
        payPanel.setBackground(new Color(255,182,193));
        payPanel.setBorder(new EmptyBorder(80, 0, 80, 0));
        //แสดงเลขบัญชี
        JLabel pay = new JLabel("0653129297 Kasikorn");
        pay.setFont(new Font("Segoe UI Black", Font.PLAIN, 20));
        payPanel.add(pay);
        payPanel.add(new JLabel());
        //แสดงชื่อบัญชี
        JLabel payname = new JLabel("Name: Kanakorn Wongchaiya");
        payname.setFont(new Font("Segoe UI Black", Font.PLAIN, 20));
        payPanel.add(payname);

        paymentPanel.add(payPanel);
        add(paymentPanel);

        //สร้าง Panel แสดงปุ่ม
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
        buttonPanel.setBorder(new EmptyBorder(10, 0, 0,0 ));
        buttonPanel.setBackground(new Color(199,21,133));
        //แสดงปุ่ม Back
        JButton backButton = new JButton("Back");
        backButton.setPreferredSize(new Dimension(150, 50));
        backButton.setFont(new Font("Segoe UI Black", Font.PLAIN, 25));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(186,85,211));
        backButton.addActionListener(new BackButtonHandler());
        buttonPanel.add(backButton);
        //แสดงปุ่ม Recipt
        JButton receiptButton = new JButton("Receipt"); // สร้างปุ่มใหม่ชื่อ Receipt
        receiptButton.setPreferredSize(new Dimension(150, 50));
        receiptButton.setFont(new Font("Segoe UI Black", Font.PLAIN, 25));
        receiptButton.setBackground(new Color(186,85,211));
        receiptButton.setForeground(Color.WHITE);
        receiptButton.addActionListener(new ReceiptButtonHandler()); // เชื่อม ActionListener ให้กับปุ่ม Receipt  
        buttonPanel.add(receiptButton);
    
        add(buttonPanel, BorderLayout.SOUTH);
    }

    //สร้างเมทอดคำนวณราคารวม 
    private int calculateTotalPrice(int price, int numberOfSeats) {
        return price * numberOfSeats;
    }

    //สร้าง Action ให้ปุ่ม Back
    private class BackButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            app.showBookingPage(); // เมื่อกดปุ่ม Back ให้แสดงหน้า BookingPage
        }
    }

    //สร้าง Action ให้ปุ่ม Receipt
    private class ReceiptButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = nameLabel.getText().substring(7);
            String phoneNumber = phoneNumberLabel.getText().substring(15);
            String email = emailLabel.getText().substring(8);
            String departureStation = departureStationLabel.getText().substring(19);
            String destinationStation = destinationStationLabel.getText().substring(21);
            int price = Integer.parseInt(priceLabel.getText().substring(8, priceLabel.getText().indexOf(" Baht")));
            int totalPrice = Integer.parseInt(totalpriceLabel1.getText().substring(0, totalpriceLabel1.getText().indexOf(" Baht")));

            Data data = new Data(name, phoneNumber, email, departureStation, destinationStation, price, selectedSeats);
            app.showReceiptPage(data, selectedSeats, totalPrice);
        }
    }
}
