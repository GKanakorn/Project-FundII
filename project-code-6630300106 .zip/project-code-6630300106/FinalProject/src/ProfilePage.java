package FinalProject.src;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ProfilePage extends JPanel{
    private AppWindow app;
    private JTextField usernameTextField;
    private JTextField phoneNumberTextField;
    private JTextField emailTextField;
    private JComboBox<String> departureComboBox;
    private JComboBox<String> destinationComboBox;
    private JLabel priceLabel;
    private Map<String, Integer> priceMap;// สร้าง Map เก็บราคาตามจังหวัด

    public ProfilePage(AppWindow app){
        this.app = app;
        setLayout(new BorderLayout());
        setBackground(new Color(25,25,112));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // เตรียมข้อมูลสำหรับ ComboBox
        String[] provincesDestination = {"-- Selected --","Ayutthaya", "Chanthaburi", "Chiang Mai", "Chiang Rai","Chonburi", "Nakhon Nayok",  "Nakhon Ratchasima","Phuket", "Surat Thani","Trang"};
        String[] provincesDeparture = {"-- Selected --","Bangkok"};

        // สร้าง Map เก็บราคาตามจังหวัด
        priceMap = new HashMap<>();
        priceMap.put("-- Selected --", 0);
        priceMap.put("Trang", 790);
        priceMap.put("Nakhon Nayok", 200);
        priceMap.put("Chonburi", 150);
        priceMap.put("Nakhon Ratchasima", 500);
        priceMap.put("Ayutthaya", 250);
        priceMap.put("Chanthaburi", 450);
        priceMap.put("Chiang Mai", 900);
        priceMap.put("Chiang Rai", 900);
        priceMap.put("Phuket", 900);
        priceMap.put("Surat Thani", 800);

        //Define-Head
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(new Color(0,0,205));
        welcomePanel.setBorder(new EmptyBorder(10, 0, 0,0 ));
        JLabel welcome = new JLabel("Welcome to TrainBooking.com");
        welcome.setFont(new Font("Showcard Gothic" , Font.PLAIN , 28));
        welcome.setForeground(Color.WHITE);
        welcomePanel.add(welcome);
        add(welcomePanel, BorderLayout.PAGE_START);
        
        //Define-Body
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(14,1));
        panel.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 30));
        panel.setBackground(new Color(135,206,235));
        
        //Define-Body-Username
        JLabel usernameLabel = new JLabel("1.Username");
        usernameLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        panel.add(usernameLabel);
        usernameTextField = new JTextField();    
        panel.add(usernameTextField);
        usernameTextField.setFont(new Font("Segoe UI Black" , Font.PLAIN , 14));
        
        //Define-Body-Phone Number
        JLabel phoneNumberLabel = new JLabel("2.Phone Number");
        phoneNumberLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        panel.add(phoneNumberLabel);
        phoneNumberTextField = new JTextField();
        panel.add(phoneNumberTextField);
        phoneNumberTextField.setFont(new Font("Segoe UI Black" , Font.PLAIN , 14));
        
        //Define-Body-Email
        JLabel emailLabel = new JLabel("3.Email");
        emailLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        panel.add(emailLabel);
        emailTextField = new JTextField();
        panel.add(emailTextField);
        emailTextField.setFont(new Font("Segoe UI Black" , Font.PLAIN , 14));

        //Define-Body-Select Departure station
        JLabel departureLabel = new JLabel("4.Select Departure Province Station");
        departureLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        panel.add(departureLabel);
        departureComboBox = new JComboBox<>(provincesDeparture);
        departureComboBox.setBackground(Color.WHITE);
        departureComboBox.setFont(new Font("Segoe UI Black" , Font.PLAIN , 14));
        panel.add(departureComboBox);
        
        //Define-Body-Select Destination station
        JLabel destinationLabel = new JLabel("5.Select Destination Province Station");
        destinationLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        panel.add(destinationLabel);
        destinationComboBox = new JComboBox<>(provincesDestination);
        destinationComboBox.setBackground(Color.WHITE);
        destinationComboBox.setFont(new Font("Segoe UI Black" , Font.PLAIN , 14));
        destinationComboBox.addActionListener(new DestinationComboBoxHandler()); // เพิ่ม ActionListener สำหรับ JComboBox ที่เลือกสถานีปลายทาง
        panel.add(destinationComboBox);
        
        //Define-Body-Price per person
        JLabel priceTitleLabel = new JLabel("6.Price per person ");
        priceTitleLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        panel.add(priceTitleLabel);
        JPanel pricePanel = new JPanel();
        pricePanel.setBackground(Color.WHITE);
        priceLabel = new JLabel(""); // เพิ่ม JTextArea สำหรับแสดงราคา
        priceLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 18));
        priceLabel.setForeground(Color.MAGENTA);
        pricePanel.add(priceLabel);
        pricePanel.setLayout(new GridLayout(1, 2));
        panel.add(pricePanel);
        panel.add(new JLabel());

        //Define-Body-Image
        try {
            ImageIcon backgroundImage = new ImageIcon(ImageIO.read(new File("C:/Users/guy91/Desktop/ProgramFund II/project-code-6630300106/FinalProject/src/Image/TrainBooking.png")));
            JLabel backgroundLabel = new JLabel(backgroundImage);
            // เพิ่ม JLabel เข้าไปใน JPanel
            panel.add(backgroundLabel);
        } catch (IOException e) {
            e.printStackTrace(); // หรือจัดการกับ Exception ตามที่เหมาะสม
        }
        add(panel , BorderLayout.CENTER);
  
        //Define-Button
        JButton bookingButton = new JButton("Booking!");
        bookingButton.addActionListener(new BookingButtonHandler());
        bookingButton.setBackground(new Color(255,165,0));
        bookingButton.setFont(new Font("Segoe UI Black" , Font.PLAIN , 25));
        bookingButton.setForeground(Color.WHITE);
        bookingButton.setPreferredSize(new Dimension(150 , 50));
        
        //Define-Panel-Add-Button
        JPanel profilePanel = new JPanel();
        profilePanel.add(bookingButton);
        profilePanel.setBackground(new Color(0,0,205));
        add(profilePanel , BorderLayout.PAGE_END);
    }

    //สร้าง Action ให้ปุ่ม Booking
    private class BookingButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (isValidData()) {
                String name = usernameTextField.getText();
                String phoneNumber = phoneNumberTextField.getText();
                String email = emailTextField.getText();
                String departure = (String) departureComboBox.getSelectedItem();
                String destination = (String) destinationComboBox.getSelectedItem();
                int price = priceMap.get(destination);
    
                Data data = new Data(name, phoneNumber, email, departure, destination, price);
                app.bookingButtonPressed(data);
                app.revalidate();
            }
        }
    }

    //สร้าง Action ให้ปุ่ม DestinationComboBox
    private class DestinationComboBoxHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            /*เมื่อเลือกสถานีปลายทางจาก destinationComboBox โดยใช้ getSelectedItem() ส่งคืนอ็อบเจกต์ที่ถูกเลือก 
            และแปลงอ็อบเจกต์นั้นเป็น String โดยใช้เพื่อนำไปใช่งานต่อ เก็บจังหวัดที่ถูกเลือกไว้ในตัวแปร selectedDestination*/
            String selectedDestination = (String) destinationComboBox.getSelectedItem();
            //ใช้เข้าถึงข้อมูลราคาของการเดินทางตามสถานีปลายทางที่ โดยใช้ priceMap เป็น Map ที่เก็บราคาตามจังหวัด
            int price = priceMap.get(selectedDestination);
            //ใช้แสดงราคาที่ได้จาก priceMap โดยใช้ setText() เพื่อกำหนดข้อความที่จะแสดงบน JLabel ที่ชื่อ priceLabel โดยแปลงค่า price ให้เป็น String
            priceLabel.setText(Integer.toString(price) + " Bath/person");
        }
    }

    //สร้างเมทอดให้เช็คว่าช่องที่รับค่าเข้ามาเป็นช่องว่างหรือไม่และใน ComboBox มีการเลือกสถานีต้นทางและสถานีปลายทางหรือไม่
    private boolean isValidData() {
        // ตรวจสอบว่าข้อมูลในช่อง Name, PhoneNumber, Email ถูกป้อนหรือไม่
        if (usernameTextField.getText().isEmpty() || phoneNumberTextField.getText().isEmpty() || emailTextField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(app, "Please fill in all the required information.");
            return false;
        }
        // ตรวจสอบว่า ComboBox สถานีปลายทางและสถานีต้นทางถูกเลือกหรือไม่
        if (departureComboBox.getSelectedItem().equals("-- Selected --") || destinationComboBox.getSelectedItem().equals("-- Selected --")) {
            JOptionPane.showMessageDialog(app, "Please select departure and destination stations.");
            return false;
        }
        //ถ้าพบว่ามีข้อความ
        return true;
    }
}
