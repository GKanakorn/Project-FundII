package FinalProject.src;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Set;

public class Receipt extends JPanel {
    private AppWindow app;
    private JLabel nameLabel;
    private JLabel phoneNumberLabel;
    private JLabel emailLabel;
    private JLabel departureStationLabel;
    private JLabel destinationStationLabel;
    private JLabel priceLabel;
    private JLabel seatLabel;

    public Receipt(AppWindow app, Data data, Set<String> selectedSeats, int totalPrice) {
        this.app = app;
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(10, 10, 10, 10));
        setBackground(new Color(220,20,60));
        
        //สร้าง Panel
        JPanel topPanel = new JPanel(new GridLayout(8, 1));
        topPanel.setBorder(new EmptyBorder(10, 10, 10, 0));
        topPanel.setBackground(new Color(220,220,220));

        //ส่วนแสดงข้อมูลผู้ใช้และรายละเอียดการจอง
        //ชื่อ
        nameLabel = new JLabel("Name : " + data.getName());
        nameLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        topPanel.add(nameLabel);
        //เบอร์โทร
        phoneNumberLabel = new JLabel("Phone Number : " + data.getPhoneNumber());
        phoneNumberLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        topPanel.add(phoneNumberLabel);
        //อีเมล
        emailLabel = new JLabel("Email : " + data.getEmail());
        emailLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        topPanel.add(emailLabel);
        //สถานีต้นทาง
        departureStationLabel = new JLabel("Departure Station :" + data.getDepartureStation());
        departureStationLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        topPanel.add(departureStationLabel);
        //สถานีปลายทาง
        destinationStationLabel = new JLabel("Destination Station :" + data.getDestinationStation());
        destinationStationLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        topPanel.add(destinationStationLabel);
        //ราคา
        priceLabel = new JLabel("Price : " + data.getPrice() + " Baht/Person");
        priceLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        topPanel.add(priceLabel);
        //ที่นั่ง
        seatLabel = new JLabel("Selected Seats : " + selectedSeats); 
        seatLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        topPanel.add(seatLabel);
        //ราคารวม
        JLabel totalPriceLabel = new JLabel("Total Price: " + totalPrice + " Baht");
        totalPriceLabel.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        totalPriceLabel.setForeground(Color.RED);
        topPanel.add(totalPriceLabel);

        add(topPanel);
        
        //สร้าง Panel ปุ่ม Exit
        JPanel exitPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        exitPanel.setBackground(new Color(220,20,60));
        //ปุ่ม Exit
        JButton exitButton = new JButton("Exit");
        exitButton.setPreferredSize(new Dimension(120, 25));
        exitButton.setFont(new Font("Segoe UI Black", Font.PLAIN, 14));
        exitButton.setBackground(new Color(255,215,0));
        exitButton.addActionListener(new ExitButtonHandler());
        
        exitPanel.add(exitButton);
        add(exitPanel, BorderLayout.SOUTH);
    }

    //สร้าง Action ให้ปุ่ม Exit
    private class ExitButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int confirmed = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit Confirmation", 
                                                            JOptionPane.YES_NO_OPTION);
            if (confirmed == JOptionPane.YES_OPTION) {
                app.dispose(); // ปิด AppWindow
            }
        }
    }
}
