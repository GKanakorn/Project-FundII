package FinalProject.src;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class BookingPage extends JPanel {
    private AppWindow app;
    private JLabel nameLabel;
    private JLabel phoneNumberLabel;
    private JLabel emailLabel;
    private JLabel departureStationLabel;
    private JLabel destinationStationLabel;
    private JLabel priceLabel;
    private Set<String> selectedSeats; // เก็บที่นั่งที่เลือก

    public BookingPage(AppWindow app , Data data){
        this.app = app;
        selectedSeats = new HashSet<>();
        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(10, 10, 10, 10));
        setBackground(new Color(46,139,87));

        JPanel showdata = new JPanel(new GridLayout(1, 1));

        //สร้างส่วนแสดงข้อมูลผู้ใช้ ชื่อ เบอร์โทร อีเมล
        JPanel userInfoPanel = new JPanel(new GridLayout(3, 1));
        userInfoPanel.setBackground(new Color(143,188,143));
        userInfoPanel.setBorder(new EmptyBorder(10, 10, 10, 0));
        
        //แสดงชื่อ
        nameLabel = new JLabel("Name : " + data.getName());
        nameLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 16));
        userInfoPanel.add(nameLabel);

        //แสดงเบอร์โทร
        phoneNumberLabel = new JLabel("Phone Number : " + data.getPhoneNumber());
        phoneNumberLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 16));
        userInfoPanel.add(phoneNumberLabel);

        //แสดงอีเมล
        emailLabel = new JLabel("Email : " + data.getEmail());
        emailLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 16));
        userInfoPanel.add(emailLabel);
        
        //สร้าง JPanel สำหรับการเลือกสถานี,ราคา
        JPanel stationPanel = new JPanel(new GridLayout(3, 1));
        stationPanel.setBackground(new Color(143,188,143));
        stationPanel.setBorder(new EmptyBorder(10, 0, 10, 0));

        //แสดงสถานีต้นทาง
        departureStationLabel = new JLabel("Departure Station : " + data.getDepartureStation());
        departureStationLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 16));
        stationPanel.add(departureStationLabel);

        //แสดงสถานีปลายทาง
        destinationStationLabel = new JLabel("Destination Station : " + data.getDestinationStation());
        destinationStationLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 16));
        stationPanel.add(destinationStationLabel);

        //แสดงราคา
        priceLabel = new JLabel("Price : " + data.getPrice() + " Baht/Person");
        priceLabel.setFont(new Font("Segoe UI Black" , Font.PLAIN , 16));
        stationPanel.add(priceLabel);
        
        //เพิ่มส่วนแสดงข้อมูลต่างๆ ลง showdata
        showdata.add(userInfoPanel);
        showdata.add(stationPanel);
        add(showdata , BorderLayout.PAGE_START);

        // สร้างส่วนแสดงที่นั่ง
        JPanel seat = new JPanel();
        seat.setLayout(new GridLayout(1,1));
        seat.setBorder(new EmptyBorder(10, 0, 10, 0));
        seat.setBackground(new Color(46,139,87));
        
        //สร้างแผนผังที่นั่งทางซ้ายของจอ
        JPanel leftseat = new JPanel();
        leftseat.setLayout(new BoxLayout(leftseat, BoxLayout.PAGE_AXIS)); // เปลี่ยนเป็น BoxLayout
        leftseat.setBorder(new EmptyBorder(10, 10, 10, 10));
        char[] rows = {'A', 'B', 'C', 'D'};
        for (int i = 1; i <= 9; i++) {
            JPanel rowPanel = new JPanel();
            rowPanel.setLayout(new BoxLayout(rowPanel, BoxLayout.LINE_AXIS));
            rowPanel.setBorder(new EmptyBorder(5, 5, 5, 0));
            for (char row : rows) {
                JButton seatButton = new JButton(row + String.valueOf(i));
                seatButton.addActionListener(new SeatButtonHandler()); // เพิ่ม ActionListener ในปุ่มที่นั่ง
                seatButton.setPreferredSize(new Dimension(50, 50)); // กำหนดขนาดของปุ่ม
                seatButton.setBackground(Color.WHITE);
                rowPanel.add(seatButton);
                rowPanel.setBackground(new Color(102,205,170));
                rowPanel.add(Box.createRigidArea(new Dimension(5, 5))); // เพิ่มพื้นที่ว่างระหว่างปุ่ม
            }
 
            leftseat.add(rowPanel);
            leftseat.setBackground(new Color(144,238,144));
        }
        seat.add(leftseat, BorderLayout.CENTER);

        //สร้างหน้าต่างข้างขวา
        JPanel rightSeat = new JPanel(new GridLayout(2,1));

        //เพิ่ม Status ของ Seats
        JPanel seatStatus = new JPanel();
        seatStatus.setLayout(new GridLayout(3,1));
        seatStatus.setBorder(new EmptyBorder(20,20,20,20));
        seatStatus.setBackground(new Color(144,238,144));
        //เพิ่ม Status ของ Seats-Already Reserved
        JButton seatStatusAlreadyReserved = new JButton("Already Reserved");
        seatStatusAlreadyReserved.setBackground(Color.RED);
        seatStatusAlreadyReserved.setPreferredSize(new Dimension(150 , 50));
        seatStatusAlreadyReserved.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        seatStatus.add(seatStatusAlreadyReserved);
        //เพิ่ม Status ของ Seats-Selected
        JButton seatStatusSelected = new JButton("Selected");
        seatStatusSelected.setBackground(Color.MAGENTA);
        seatStatusSelected.setPreferredSize(new Dimension(150 , 50));
        seatStatusSelected.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        seatStatus.add(seatStatusSelected);
        //เพิ่ม Status ของ Seats-Empty
        JButton seatStatusEmpty = new JButton("Empty");
        seatStatusEmpty.setBackground(Color.WHITE);
        seatStatusEmpty.setPreferredSize(new Dimension(150 , 50));
        seatStatusEmpty.setFont(new Font("Segoe UI Black" , Font.PLAIN , 20));
        seatStatus.add(seatStatusEmpty);
        //เพิ่ม Status ลงใน rightSeat
        rightSeat.add(seatStatus);

        //เพิ่มรูปลงน่ารักๆ
        JPanel image = new JPanel();
        image.setBackground(new Color(144,238,144));
        try {
            ImageIcon backgroundImage = new ImageIcon(ImageIO.read(new File("C:/Users/guy91/Desktop/ProgramFund II/project-code-6630300106/FinalProject/src/Image/ticket.png")));
            JLabel backgroundLabel = new JLabel(backgroundImage);
            // เพิ่ม JLabel เข้าไปใน JPanel
            image.add(backgroundLabel);
        } catch (IOException e) {
            e.printStackTrace(); // หรือจัดการกับ Exception ตามที่เหมาะสม
        }
        //เพิ่ม image ลงใน rightSeat
        rightSeat.add(image);
        
        //เพิ่ม rightSeat ลง Panel Seat
        seat.add(rightSeat);
        add(seat);

        //สร้าง Panel สำหรับใส่ปุ่ม
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));

        // สร้างปุ่ม Back
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new BackButtonHandler());
        backButton.setPreferredSize(new Dimension(150 , 50));
        backButton.setFont(new Font("Segoe UI Black" , Font.PLAIN , 25));
        backButton.setBackground(new Color(0,255,0));
        buttonPanel.add(backButton);
         
        // สร้างปุ่ม Payment
        JButton paymentButton = new JButton("Payment");
        paymentButton.addActionListener(new PaymentButtonHandler());
        paymentButton.setPreferredSize(new Dimension(150 , 50));
        paymentButton.setFont(new Font("Segoe UI Black" , Font.PLAIN , 25));
        paymentButton.setBackground(new Color(0,255,0));
        buttonPanel.add(paymentButton);
         
        // เพิ่มปุ่มไปยังตำแหน่งใน BorderLayout ของ BookingPage
        add(buttonPanel, BorderLayout.PAGE_END);
    }

    //เพิ่ม Action ให้ปุ่มที่นั่ง
    private class SeatButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton button = (JButton) e.getSource();//ดึงอ็อบเจกต์ JButton ที่ทำให้เกิด ActionEvent โดยใช้เมทอด getSource() ของอ็อบเจกต์ ActionEvent ที่ถูกส่งมา.
            String seat = button.getText();//ดึงข้อความที่ปุ่มมีอยู่ ซึ่งในที่นี้คือตำแหน่งหมายเลขที่นั่ง โดยใช้เมทอด getText() ของอ็อบเจกต์ JButton.
            //สร้างเงื่อนไขเพื่อตรวจสอบว่าที่นั่งที่ผู้ใช้คลิกเลือกอยู่ในเซ็ตของที่นั่งที่ถูกเลือกหรือไม่.
            if (selectedSeats.contains(seat)) {
                selectedSeats.remove(seat); // ถ้าที่นั่งถูกเลือกแล้ว ก็ลบออกจากเซ็ต
                button.setBackground(Color.WHITE); // ลบสีพื้นหลังที่เลือก
            } else {
                selectedSeats.add(seat); // ถ้าที่นั่งยังไม่ถูกเลือก ก็เพิ่มเข้าไปในเซ็ต
                button.setBackground(Color.MAGENTA); // ตั้งสีพื้นหลังเป็นสีม่วงเมื่อเลือก
            }
        }
    }

    //เพิ่ม Action ให้ปุ่ม Back
    private class BackButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            app.showProfilePage(); // เมื่อกดปุ่ม Back ให้แสดงหน้า ProfilePage
        }
    }

    //เพิ่ม Action ให้ปุ่ม Payment 
    private class PaymentButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // ตรวจสอบว่ามีที่นั่งที่ถูกเลือกหรือไม่
            if (selectedSeats.isEmpty()) {
                JOptionPane.showMessageDialog(app, "Please select a seat before proceeding to payment.");
                return; // ไม่ทำงานต่อหากไม่มีที่นั่งที่ถูกเลือก
            }
            // ดึงข้อมูลจาก Label และใช้ในการสร้าง Data object
            String name = nameLabel.getText().substring(7); // ตัดคำว่า "Name: " ออก
            String phoneNumber = phoneNumberLabel.getText().substring(15); // ตัดคำว่า "Phone Number: " ออก
            String email = emailLabel.getText().substring(8); // ตัดคำว่า "Email: " ออก
            String departureStation = departureStationLabel.getText().substring(19); // ตัดคำว่า "Departure Station : " ออก
            String destinationStation = destinationStationLabel.getText().substring(21); // ตัดคำว่า "Destination Station : " ออก
            int price = Integer.parseInt(priceLabel.getText().substring(8, priceLabel.getText().indexOf(" Baht"))); // ตัดคำว่า "Price: " และเอาเฉพาะตัวเลขราคา
            
            // สร้าง Data object ใหม่ พร้อมกับการส่ง selectedSeats
            Data data = new Data(name, phoneNumber, email, departureStation, destinationStation, price , selectedSeats);
                
            // ส่งข้อมูลไปยัง AppWindow เพื่อเปิดหน้า PaymentPage
            app.paymentButtonPressed(data,selectedSeats);
            app.revalidate();
        }
    }
} 