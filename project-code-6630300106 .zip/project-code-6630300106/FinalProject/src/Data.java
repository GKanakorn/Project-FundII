package FinalProject.src;

import java.util.Set;

public class Data {
    private String name;
    private String phoneNumber;
    private String email;
    private String departureStation;
    private String destinationStation;
    private int price;
    private Set<String> selectedSeats;

    // Constructor
    public Data(String name, String phoneNumber, String email, String departureStation, String destinationStation, int price ,  Set<String> selectedSeats) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.departureStation = departureStation;
        this.destinationStation = destinationStation;
        this.price = price;
        this.selectedSeats = selectedSeats;
    }

    public Data(String name, String phoneNumber, String email, String departureStation, String destinationStation, int price) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.departureStation = departureStation;
        this.destinationStation = destinationStation;
        this.price = price;
    }
    
    // Getters
    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartureStation() {
        return departureStation;
    }

    public String getDestinationStation() {
        return destinationStation;
    }

    public int getPrice() {
        return price;
    }

    public Set<String> getSelectedSeats() {
        return selectedSeats;
    }
}
